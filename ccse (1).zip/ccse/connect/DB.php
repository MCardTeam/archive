<?php

/**
 * 
 */
class DB 
{
	private $db;
	function __construct()
	{
		# code...
		$this->db=new PDO("mysql:host=localhost;dbname=ccse","root","");
	}

	
public function login($id,$pass){
	$sql=$this->db->prepare("SELECT * FROM admin WHERE email=? AND pass=?");
	$sql->execute(array($id,$pass));
	if ($sql->rowCount()==1) {
		foreach ($sql as $key ) {
			
				$_SESSION['id']=$id;
				$_SESSION['pass']=$pass;
			
				header("index.php");
			}

			
		}
	}
}


