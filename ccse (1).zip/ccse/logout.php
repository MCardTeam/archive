<!--
Into this file, we write a code for logout.
-->
<?php
session_start();
$_SESSION = array();
session_destroy();
header("Location: index.php");
?>