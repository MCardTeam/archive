
<?php
session_start();


include_once("connection.php");
if (isset($_POST['keySubmit'])) {
	# code...
	if (isset($_POST['keyRole']) && $_POST['keyRole'] == "Admin") {
		# code...
		if(isset($_POST['keyID']) && isset($_POST['keyPassword'])){
			$id = $_POST['keyID'];
			$password = $_POST['keyPassword'];
			$query = "SELECT * FROM admin WHERE id = '$id' AND pass = '$password'";
			$result = mysqli_query($conn, $query);
			if($result->num_rows > 0){
				$_SESSION['keyID'] = $id;
				header("Location: admin.php");	
				}
			else{
				echo "Wrong id and password";
				exit;
			}
		}


	}
	if (isset($_POST['keyRole']) && $_POST['keyRole'] == "Staff") {
		# code...
		if(isset($_POST['keyID']) && isset($_POST['keyPassword'])){
			$id = $_POST['keyID'];
			$password = $_POST['keyPassword'];
			$query = "SELECT * FROM teacher WHERE id = '$id' AND pass = '$password'";
			$result = mysqli_query($conn, $query);
			if($result->num_rows > 0){
				$_SESSION['keyID'] = $id;
				header("Location: secTeacher.php");
			}
			else{
				echo "Wrong id and password";
				exit;
			}
		}


	}

	if (isset($_POST['keyRole']) && $_POST['keyRole'] == "Student") {
			# code...
			if(isset($_POST['keyID']) && isset($_POST['keyPassword'])){
				$id = $_POST['keyID'];
				$password = $_POST['keyPassword'];
				$query = "SELECT * FROM student WHERE id = '$id' AND pass = '$password'";
				$result = mysqli_query($conn, $query);
				if($result->num_rows > 0){
					$_SESSION['keyID'] = $id;

					header("Location: sec.php");				}

				else{
					echo "Wrong id and password";
					exit;
				}
			}


	}

}



?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>CCSE Archive</title>
	<link rel="icon" type="image/png" href="img/img.jpg"/>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>
<body>

	<!-- ====================================================
	header section -->

	<header class="top-header">
		<div class="info">
			<a href="mailto:info@info.com" ><i class="fa fa-envelope-o"></i> info@info.com</a>
			<h5>CCSE-HAIL</h5>
		</div>
		<div class="container">
			<div class="row">
				<div class=""> <!-- col-md-7-->
					<nav class="navbar navbar-default">
					  <div class="container-fluid nav-bar">
					    <!-- Brand and toggle get grouped for better mobile display -->
					    <div class="navbar-header">
					      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        <span class="sr-only">Toggle navigation</span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					      </button>
					    </div>

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							  <img src="">
					      <ul class="nav navbar-nav navbar-left">
					      	<!--**************************************************** -->
					      	<li><img src="img/logoo.png" width="50" height="50"></li>
					        <li><a class="menu active" href="index.php" >Home</a></li>
					        <li><a class="menu" href="abouthome.php">about us</a></li>
					        <li><a class="menu" target='_blank' href="http://www.uoh.edu.sa/Pages/default.aspx"> UOH</a></li>			
									
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
	</header> <!-- end of header area -->

	<section  id="home">


	</section><!-- end of slider section -->

	<!-- service section starts here -->
	<section class="contact " id="contact">

		<div class="limiter">

			<div class="container-login">

				<div class="wrap-login">

					<form  class="login-form validate-form" action="<?PHP $_PHP_SELF ?>" method="post">
	

						<h1 class="login-form-title p-b-43">
							Login
						</h1>
						<img  src="img/ccse.jpeg" width="50" height="50" style="display: block; margin-left: auto; margin-right: auto;">


						<select class="input" name="keyRole">
								<option disabled="disabled" selected="selected">Please select your role</option>
								<option>Admin</option>
								<option>Staff</option>
								<option>Student</option>
						</select>
						<br>

						<div class="wrap-input validate-input">
							<input class="input" type="text" name="keyID">
							<span class="focus-input"></span>
							<span class="label-input">ID</span>
						</div>


						<div class="wrap-input validate-input" data-validate="Password is required">
							<input class="input" type="password" name="keyPassword">
							<span class="focus-input"></span>
							<span class="label-input">Password</span>
						</div>

						<div class="flex-sb-m w-full p-t-3 p-b-32">
							<div class="">
								<input class="input-checkbox" id="ckb1" type="checkbox" name="remember-me">
								<label class="label-checkbox" for="ckb1">Remember me</label>
							</div>

							<div class="forgot">
								<a href="#">
									Forgot Password?
								</a>
							</div>
						</div>


						<div class="container-login-form-btn">
							<button class="login-form-btn" name="keySubmit">
								Login
							</button>
						</div>

					</form>

					<div >
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of service section -->
	<!-- footer starts here -->
	<footer class="footer ">
		<p>&copy; All right reserved <spa>CCSE students</spa></p>
		</footer>
	<!-- script tags
	============================================================= -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
