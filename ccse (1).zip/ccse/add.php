<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Add user</title>
	<link rel="icon" type="image/png" href="img/img.jpg"/>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>
<body>

	<!-- ====================================================
	header section -->

	<header class="top-header">
		<div class="info">
			<a href="mailto:info@info.com" ><i class="fa fa-envelope-o"></i> info@info.com</a>
			<h5>CCSE-HAIL</h5>
		</div>
		<div class="container">
			<div class="row">
				<div class=""> <!-- col-md-7-->
					<nav class="navbar navbar-default">
					  <div class="container-fluid nav-bar">
					    <!-- Brand and toggle get grouped for better mobile display -->
					    <div class="navbar-header">
					      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        <span class="sr-only">Toggle navigation</span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					      </button>
					    </div>

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							  <img src="">
					      <ul class="nav navbar-nav navbar-left">
                         <li><img src="img/logoo.png" width="70" height="70"></li>

					        <li><a class="menu active" href="index.php" >Home</a></li>
					        <li><a class="menu" href="about.php">about us</a></li>
					        <li><a class="menu" href="http://www.uoh.edu.sa/Pages/default.aspx"> UOH</a></li>
									<li><a class="menu" href="logout.php">Log Out</a></li>
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
	</header> <!-- end of header area -->

  <div class="add" id="user">

    		<div class="limiter">
    			<div class="container-adduser">
    				<div class="wrap-login">
    					<form class="login-form validate-form" action="registration_code.php" method="POST">
    						<h1 class="login-form-title p-b-43">
    							<p>Add User</p>
    						</h1>
                            <div class="wrap-input validate-input" >
                                <input class="input" type="text" name="keyId">
                                <span class="focus-input"></span>
                                <span class="label-input">ID</span>
                            </div>

                            <div class="wrap-input validate-input" >
    							<input class="input" type="text" name="keyName">
    							<span class="focus-input"></span>
    							<span class="label-input">Name</span>
    						</div>
                            <div class="wrap-input validate-input" >
                                <input class="input" type="password" name="keyPassword">
                                <span class="focus-input"></span>
                                <span class="label-input">Password</span>
                            </div>

                
                            <div class="wrap-input validate-input" >
    							<input class="input" type="text" name="keyPhone">
    							<span class="focus-input"></span>
    							<span class="label-input">Mobile</span>
    						</div>
    						<div class="wrap-input validate-input" >
    							<input class="input" type="email" name="keyEmail">
    							<span class="focus-input"></span>
    							<span class="label-input">Email</span>
    						</div>
                            <!-- 
                <div class="wrap-input validate-input" data-validate = "Valid UserName is required">
                  <input class="input" type="text" name="uname">
                  <span class="focus-input"></span>
                  <span class="label-input">UserName</span>
                </div>
                
    						-->
                <select class="input" data-validate ="please select one " name="keyRole">
                    <option disabled="disabled" selected="selected">Specility</option>
                    <option>Staff</option>
                    <option>Student</option>
                </select>
                <br>
            

    							<button class="login-form-btn" name="keySubmit"> Create </button>
                  <br>
    							<a href="mng.php"><button type="button" class="login-form-btn">Cancel </button></a>

                </form>
              </div>
             </div>
            </div>

  </div>
	<!-- footer starts here -->
	<footer class="footer ">
		<p>&copy; All right reserved <spa>CCSE students</spa></p>
		</footer>
	<!-- script tags
	============================================================= -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
