
<?php
include_once('connection.php');
$id = $name = $password = $email = $phone  = '';

$id = $_POST['keyId'];
$name = $_POST['keyName'];
$password = $_POST['keyPassword'];
$email = $_POST['keyEmail'];
$phone = $_POST['keyPhone'];

if (isset($_POST['keySubmit'])) {
if (isset($_POST['keyRole']) && $_POST['keyRole'] == "Student") {
	# code...
	$sql = "INSERT INTO student (id,name,email,pass,phone) VALUES ('$id','$name','$email','$password','$phone')";
	$result = mysqli_query($conn, $sql);
	if($result > 0)
	{
		header("Location: mng.php");
	}
	else
	{
		echo "Error :".$sql;
	}

}
if (isset($_POST['keyRole']) && $_POST['keyRole'] == "Staff" ){
	# code...
	$sql = "INSERT INTO teacher (id,name,pass,email,phone) VALUES ('$id','$name','$password','$email','$phone')";
	$result = mysqli_query($conn, $sql);
	if($result > 0)
	{
		header("Location: mng.php");
	}
	else
	{
		echo "Error :".$sql;
	}
}
}
?>