<?PHP
session_start();
include_once("connection.php");
$query = "SELECT * FROM ics ORDER BY id DESC";
$result = mysqli_query($conn, $query);


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>ICS</title>
	<link rel="icon" type="image/png" href="img/img.jpg"/>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->	

<!--===============================================================================================-->
	
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>
<body>

	<!-- ====================================================
	header section -->

	<header class="top-header">
		<div class="info">
			<a href="mailto:info@info.com" ><i class="fa fa-envelope-o"></i> info@info.com</a>
			<h5>CCSE-HAIL</h5>
		</div>
		<div class="container">
			<div class="row">
				<div class=""> <!-- col-md-7-->
					<nav class="navbar navbar-default">
					  <div class="container-fluid nav-bar">
					    <!-- Brand and toggle get grouped for better mobile display -->
					    <div class="navbar-header">
					      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        <span class="sr-only">Toggle navigation</span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					      </button>
					    </div>

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							  <img src="">
					      <ul class="nav navbar-nav navbar-left">
					      	<li><img src="img/logoo.png" width="70" height="70"></li>

					        <li><a class="menu active" href="sec.php" >Home</a></li>
					        <li><a class="menu" href="about.php">about us</a></li>
					        <li><a class="menu" href="http://www.uoh.edu.sa/Pages/default.aspx"> UOH</a></li>
					        <li><a class="menu" href="sec.php"> Sections</a></li>

									<li><a class="menu" href="logout.php"> Log Out</a></li>
                         

<!-- The form -->
<form class="example" action="<?PHP $_PHP_SELF ?>" method="post">
<?php
$conn = mysqli_connect("127.0.0.1", "root", "", "ccse") or die(mysql_error());
$output = '';
if (isset($_POST['search'])) {
  $searchq = $_POST['search'];
  $searchq = preg_replace("#[^0-9a-z]#i", "replacement", $searchq);
  $query = mysqli_query($conn, "SELECT DISTINCT file, type FROM ics WHERE file LIKE '%$searchq%' OR type LIKE '%$searchq%' ");
  $count = mysqli_num_rows($query);
  if ($count == 0) {
    $output = 'There were no search results!';

  }else{
    while ($row = mysqli_fetch_array($query)) {
      $file = $row['file'];
      $type = $row['type'];
      //$id = $row['id'];

      $output .= '<div> '.$file.' >> '.$type.' >> '."<a href='uploadics/".$row['file']." ' target='_blank'>View file</a>".'</div>';

  			
    
    }

  }
}
?> 

  <input type="text" placeholder="Search.." name="search">
  <button type="submit" name="submit"><i class="fa fa-search"></i></button>
  <?php print("$output")?>

</form>
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
        
        <form id="content">
  <input type="text" name="input" class="input">
  <button type="reset" class="search"></button>
</form>
	</header> <!-- end of header area -->


			<div class="service">
				<div class="container">
					<div class="">
						<br>
						<h3>ICS</h3>
					</div>
				</div>
			</div>

    <form>
     
    	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100 ver1 m-b-110">
					<div class="table100-head">
						<table>
							<thead>
								<tr class="row100 head">
									<th class="cell100 column1">File name</th>
									<th class="cell100 column2">Type</th>
									<th class="cell100 column3">View</th>
									<th class="cell100 column4">Download</th>
									
								</tr>
							</thead>
						</table>
					</div>

					</form>

					<div class="table100-body js-pscroll">
						<table>
							<tbody>
								<?php 
								while($row = mysqli_fetch_assoc($result)){
									$data[] = $row;
									$row = mysqli_fetch_array($result);
								?>
								<tr class="row100 body">
									<td class="cell100 column1"><?php echo $row['file']; ?></td>
									<td class="cell100 column2"><?php echo $row['type']; ?></td>
									<td class="cell100 column3"><?php echo "<a href='uploadics/".$row['file']." ' target='_blank'>View File</a>"?></td>
									<td class="cell100 column4"><?php echo "<a href='uploadics/".$row['file']." ' download>Download</a>"?></td>
									


									

								</tr>
								<?php
									}
								?>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
									
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
									
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
						
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
									
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
									
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
									
								</tr>

								<tr class="row100 body">
							
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
									
								</tr>

								<tr class="row100 body">
								
								</tr>

								<tr class="row100 body">
								
								</tr>
							</tbody>
						</table>
					</div>
				</div>
            </div></div></div>
    	<!-- footer starts here -->
	<footer class="footer ">
		<p>&copy; All right reserved <spa>CCSE students</spa></p>
		</footer>
	<!-- script tags
	============================================================= -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>

    
    
    
    
    
    
    
    
    
    
    
