
<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Uplaod file</title>
	<link rel="icon" type="image/png" href="img/img.jpg"/>
	<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<link rel="stylesheet" href="css/style.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <script src="j.js"></script>
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>


	<!-- ====================================================
	header section -->

	<header class="top-header">
		<div class="info">
			<a href="mailto:info@info.com" ><i class="fa fa-envelope-o"></i> info@info.com</a>
			<h5>CCSE-HAIL</h5>
		</div>
		<div class="container">
			<div class="row">
				<div class=""> <!-- col-md-7-->
					<nav class="navbar navbar-default">
					  <div class="container-fluid nav-bar">
					    <!-- Brand and toggle get grouped for better mobile display -->
					    <div class="navbar-header">
					      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					        <span class="sr-only">Toggle navigation</span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					      </button>
					    </div>

					    <!-- Collect the nav links, forms, and other content for toggling -->
					    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							  <img src="">
					      <ul class="nav navbar-nav navbar-left">
					      	<li><img src="img/logoo.png" width="70" height="70"></li>

					        <li><a class="menu active" href="upload.php" >Home</a></li>
					        <li><a class="menu" href="about.php">about us</a></li>
					        <li><a class="menu" href="http://www.uoh.edu.sa/Pages/default.aspx" target='_blank'> UOH</a></li>
					        <li><a class="menu" href="sec.php">Sections</a></li>

									<li><a class="menu" href="logout.php"> Log Out</a></li>
					      </ul>
					    </div><!-- /navbar-collapse -->
					  </div><!-- / .container-fluid -->
					</nav>
				</div>
			</div>
		</div>
	</header> <!-- end of header area -->
       <!-- service section starts here -->
<body>
	<div class="service">
		<div class="container">
			<div class="">
				<br>
				<h3>uplaod file</h3>
			</div>
		</div>
	</div>

	
	<div class="choose">
		<form action="<?PHP $_PHP_SELF ?>" method="post" enctype="multipart/form-data">

			<!-- <div class="upload-btn-wrapper">
				<button class="btn"><i class="fa fa-download" ></i>
				<br>
				<p>Click to upload your file.</p>
				</button>
				<input type="file" name="myfile" />


			</div>
 -->
			<div class="form-group">
			
				<input  type="file" name="file" />
				<br>
				 <label >Majors</label>
				 <select class="form-control" name="keyMajor">
					 <option disabled selected >Choose Section</option>
						 <option >SWE</option>
						 <option >ICS</option>
						 <option >COE</option>
				 </select>
			</div>
			<div class="form-group">
				 <label >Type</label>
				 <select class="form-control" name="keyType">
					 <option disabled selected >Choose type</option>
						 <option >Chapter</option>
						 <option >Quiz</option>
						 <option >Assignment</option>
				 </select>
			</div>
			<input type="submit" name="keySubmit" value="submit">
			<input type="reset" name="reset" value="Reset">




<?php
  $db = mysqli_connect("127.0.0.1", "root", "", "ccse");
  $msg = "";

  if (isset($_POST['keySubmit']) && isset($_POST['keyMajor']) && $_POST['keyMajor'] == "SWE") {

       $file = $_FILES['file']['name'];
    $target = "uploadswe/".basename($file);;
    $type = $_POST['keyType'];
    $sql = "INSERT INTO swe (file, type) VALUES ('$file', '$type')";
    mysqli_query($db, $sql);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      echo("<br/>file uploaded successfully");
    }else{
      //echo("Failed to upload file");
    }
    $result = mysqli_query($db, "SELECT * FROM swe WHERE file='$file'");
    $row = mysqli_fetch_array($result);
      echo "<div id= 'f_div'>";
      echo "<a target='_blank' href='uploadswe/".$row['file']." '>Your file</a>";
      echo "</div>";

  
	}

	if (isset($_POST['keySubmit']) && isset($_POST['keyMajor']) && $_POST['keyMajor'] == "ICS") {

    $file = $_FILES['file']['name'];
    $target = "uploadics/".basename($file);;
    $type = $_POST['keyType'];
    $sql = "INSERT INTO ics (file, type) VALUES ('$file', '$type')";
    mysqli_query($db, $sql);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      echo("<br/>file uploaded successfully");
    }else{
      //echo("Failed to upload file");
    }
    $result = mysqli_query($db, "SELECT * FROM ics WHERE file='$file'");
    $row = mysqli_fetch_array($result);
      echo "<div id= 'f_div'>";
      echo "<a target='_blank' href='uploadics/".$row['file']." '>Your file</a>";
      echo "</div>"; 
  
	}

	if (isset($_POST['keySubmit']) && isset($_POST['keyMajor']) && $_POST['keyMajor'] == "COE") {


    $file = $_FILES['file']['name'];
    $target = "uploadcoe/".basename($file);;
    $type = $_POST['keyType'];
    $sql = "INSERT INTO coe (file, type) VALUES ('$file', '$type')";
    mysqli_query($db, $sql);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      echo("<br/>file uploaded successfully");
    }else{
      //echo("Failed to upload file");
    }
    $result = mysqli_query($db, "SELECT * FROM coe WHERE file='$file'");
    $row = mysqli_fetch_array($result);
      echo "<div id= 'f_div'>";
      echo "<a target='_blank' href='uploadcoe/".$row['file']." '>Your file</a>";
      echo "</div>"; 
  
	}
?>
<?php
  $db = mysqli_connect("127.0.0.1", "root", "", "ccse");
  $msg = "";
  if (isset($_POST['keySubmit']) && isset($_POST['keyMajor']) && $_POST['keyMajor'] == "SWE") {
    $file = $_FILES['file']['name'];
    $target = "uploadswe/".basename($file);;
    $type = $_POST['keyType'];
    $sql = "INSERT INTO swe (file, type) VALUES ('$file', '$type')";
    mysqli_query($db, $sql);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      echo("<br/>file uploaded successfully");
    }else{
      //echo("Failed to upload file");
    }
       	
  
	}

	if (isset($_POST['keySubmit']) && isset($_POST['keyMajor']) && $_POST['keyMajor'] == "ICS") {

    $file = $_FILES['file']['name'];
    $target = "uploadics/".basename($file);;
    $type = $_POST['keyType'];
    $sql = "INSERT INTO ics (file, type) VALUES ('$file', '$type')";
    mysqli_query($db, $sql);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      echo("<br/>file uploaded successfully");
    }else{
      //echo("Failed to upload file");
    }
  
       
	}

	if (isset($_POST['keySubmit']) && isset($_POST['keyMajor']) && $_POST['keyMajor'] == "COE") {

    $file = $_FILES['file']['name'];
    $target = "uploadcoe/".basename($file);;
    $type = $_POST['keyType'];
    $sql = "INSERT INTO coe (file, type) VALUES ('$file', '$type')";
    mysqli_query($db, $sql);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      echo("<br/>file uploaded successfully");
    }else{
      //echo("Failed to upload file");
    }
    
  
	}
?>



		</form>
	</div>


	<!-- footer starts here -->
	<footer class="footer ">
		<p>&copy; All right reserved <spa>CCSE students</spa></p>
		</footer>
	<!-- script tags
	============================================================= -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
